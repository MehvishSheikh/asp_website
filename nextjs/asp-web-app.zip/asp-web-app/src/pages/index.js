import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.css'
import HeadComponent from './components/HeadComponent'
import HomeBackComponent from './components/HomeBackComponent'
import HomeMidComponent from './components/HomeMidComponent'
import FooterComponent from './components/FooterComponent'
import Script from 'next/script'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <>
      <Head>
      <title>Moderna Bootstrap Template - Index</title>
  <meta content="" name="description" />
  <meta content="" name="keywords" />
  {/* <!-- {/* Favicons */} 
  <link href="assets/img/favicon.png" rel="icon" />
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />
  {/* <!-- {/* Google Fonts */} 
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap"
    rel="stylesheet" />
  {/* <!-- {/* Vendor CSS Files */} 
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet" />
  <link href="assets/vendor/aos/aos.css" rel="stylesheet" />
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet" />
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet" />
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />
  {/* <!-- {/* Template Main CSS File */} 
  <link href="assets/css/style.css" rel="stylesheet" />
      </Head>
      <main>
       <HeadComponent />
       <HomeBackComponent /> 
       <HomeMidComponent />
       <FooterComponent />
       

      </main>
      
    <Script src="assets/vendor/purecounter/purecounter_vanilla.js"></Script>
    <Script src="assets/vendor/aos/aos.js"></Script>
    <Script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></Script>
    <Script src="assets/vendor/glightbox/js/glightbox.min.js"></Script>
    <Script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></Script>
    <Script src="assets/vendor/swiper/swiper-bundle.min.js"></Script>
    <Script src="assets/vendor/waypoints/noframework.waypoints.js"></Script>
    <Script src="assets/vendor/php-email-form/validate.js"></Script>
  
    {/* <!-- {/* Template Main JS File  --> */}
    <Script type="module" src="assets/js/main.js"></Script>
      
    </>
  )
}
